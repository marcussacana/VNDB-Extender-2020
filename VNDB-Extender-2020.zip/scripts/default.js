try {
	var main = new MainController();
	main.run();
} catch(ex) {
	console.error(ex);
}